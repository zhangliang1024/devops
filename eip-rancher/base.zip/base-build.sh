#!/bin/bash

yum install -y wget vim net-tools
