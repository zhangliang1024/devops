#!/bin/bash

rm -rf /usr/local/bin/docker-compose

echo "1.下载docker-compose"
sudo curl -L "https://github.com/docker/compose/releases/download/1.29.2/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose

echo "2.授权并建立软链接"
sudo chmod +x /usr/local/bin/docker-compose

sudo ln -s /usr/local/bin/docker-compose /usr/bin/docker-compose

echo "3.版本检查"
docker-compose --version
