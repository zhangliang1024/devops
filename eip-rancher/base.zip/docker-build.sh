#!/bin/bash

echo "1.卸载旧版本docker"
sudo yum remove docker \
                  docker-client \
                  docker-client-latest \
                  docker-common \
                  docker-latest \
                  docker-latest-logrotate \
                  docker-logrotate \
                  docker-engine
				  
				  
echo "2.安装yum-utils"
sudo yum install -y yum-utils


echo "3.添加阿里云docker的yum源"
sudo yum-config-manager \
    --add-repo \
    http://mirrors.aliyun.com/docker-ce/linux/centos/docker-ce.repo
	
	
echo "4.安装docker引擎"
sudo yum -y install docker-ce docker-ce-cli containerd.io

	
echo "5.启动docker"
sudo systemctl start docker

	
echo "6.运行hello-world镜像"
sudo docker run hello-world
