#!/bin/bash
tag=eip-base/jdk

docker build -t $tag:latest .

